ARACNE
Typeface � ANTIPIXEL. 2012. All Rights Reserved
http://www.antipixel.com.ar
Julia Martinez Diana.

All commercial uses of any of my fonts requires a licensing fee. Please contact me to info@antipixel.com.ar with any questions beforehand.

Todo uso comercial de esta tipografia requiere el pago de su licencia. Por favor, contactame por cualquier duda a info@antipixel.com.ar